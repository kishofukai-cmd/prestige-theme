

    
    
    
    
    
    
    
    
    
    
    
            
          
            
          
    
    
    
    
            
          
    
    
    
    
            
          
            
          
    
    
    
    
            
          
    
    
    
    
    
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309').children('.module');

  var sameHeightTitle = $module.data('sameheightitle'),
  spacing = $module.data('spacing');
  collg = $module.data('collg'),
  colmd = $module.data('colmd'),
  colsm = $module.data('colsm'),
  colxs = $module.data('colxs');

  var $clearfixes = $module.find('.gf_row-no-padding').children('.gf_clearfix');
  var col = collg;

  jQuery(window).resize(function() {
    setTimeout(function() {
      for(var i = 0; i < $clearfixes.length; i++) {
        if($clearfixes.eq(i).css('display') == 'block') {
          if($clearfixes.eq(i).hasClass('visible-lg')) {
            col = collg;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-md')) {
            col = colmd;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-sm')) {
            col = colsm;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-xs')) {
            col = colxs;
            break;
          }
        }
      }
    }, 1000);
  });

  jQuery($module).css('padding', spacing);
})( window.GemQuery || jQuery );
    
    
  
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child1').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child1-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child1-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child1-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child2').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child2-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child2-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child2-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child3').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child3-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child3-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child3-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child4').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child4-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child4-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child4-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child5').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child5-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child5-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child5-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child6').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child6-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child6-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child6-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child7').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child7-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child7-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child7-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child8').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634813214309-child8-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634813214309-child8-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634813214309-child8-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688').children('.module');

  var sameHeightTitle = $module.data('sameheightitle'),
  spacing = $module.data('spacing');
  collg = $module.data('collg'),
  colmd = $module.data('colmd'),
  colsm = $module.data('colsm'),
  colxs = $module.data('colxs');

  var $clearfixes = $module.find('.gf_row-no-padding').children('.gf_clearfix');
  var col = collg;

  jQuery(window).resize(function() {
    setTimeout(function() {
      for(var i = 0; i < $clearfixes.length; i++) {
        if($clearfixes.eq(i).css('display') == 'block') {
          if($clearfixes.eq(i).hasClass('visible-lg')) {
            col = collg;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-md')) {
            col = colmd;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-sm')) {
            col = colsm;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-xs')) {
            col = colxs;
            break;
          }
        }
      }
    }, 1000);
  });

  jQuery($module).css('padding', spacing);
})( window.GemQuery || jQuery );
    
    
  
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child1').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child1-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child1-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child1-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child2').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child2-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child2-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child2-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child3').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child3-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child3-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child3-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child4').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child4-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child4-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child4-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child5').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child5-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child5-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child5-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child6').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child6-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child6-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child6-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child7').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child7-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child7-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child7-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child8').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1634811645688-child8-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1634811645688-child8-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1634811645688-child8-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
    
    
    
    
            
          
    
    
    
    
    
    
            
          
    
    
            
          
    
    
            
          
    
    
    
    
    
    
    
            
          
    
    
    
            
          
            
          
    
            
          
            
          
    
            
          
            
          
            
          
    
    
    
            
          
            
          
    
            
          
            
          
    
    
    
            
          
    
            
          
            
          
    
            
          
    
    
    
    
            
          
    
    
            
          
    
    
            
          
    
    
    
    
    
    
            
          
    
    
    
    
    
    
    
    
    
    
    
    
    
            
          
    
    
    
    
    
    
            
          
    
            
          
    
    
(function( jQuery ){
  try {
    var $module = jQuery('#m-1640251434626').children('.module');   
    var navspeed = $module.data('navspeed'),
      autoplaytimeout = $module.data('autoplaytimeout'),
      autoplayhoverpause = $module.data('autoplayhoverpause'),
      navlg = $module.data('navlg'),
      navmd = $module.data('navmd'),
      navsm = $module.data('navsm'),
      navxs = $module.data('navxs'),
      collg = $module.data('collg'),
      colmd = $module.data('colmd'),
      colsm = $module.data('colsm'),
      colxs = $module.data('colxs'),
      dotslg = $module.data('dotslg'),
      dotsmd = $module.data('dotsmd'),
      dotssm = $module.data('dotssm'),
      dotsxs = $module.data('dotsxs'),
      marginlg = parseInt($module.data('marginlg')),
      marginmd = parseInt($module.data('marginmd')),
      marginsm = parseInt($module.data('marginsm')),
      marginxs = parseInt($module.data('marginxs'));

    var mode = jQuery('.gryffeditor').hasClass('editing') ? 'dev' : 'production';
    if(mode == 'production') {
      var autoplay = $module.data('autoplay'), 
          loop = $module.data('loop');
    } else {
      var autoplay = 0, 
          loop = 0;
    }

    var initCarousel = function() {
      $module.owlCarousel({
        mouseDrag: false,
        autoplayHoverPause: autoplayhoverpause,
        autoplay: autoplay,
        autoplaySpeed: navspeed,
        autoplayTimeout: autoplaytimeout,
        loop: loop,
        navSpeed: navspeed,
        autoWidth: !1,
        responsiveClass:true,
        responsive:{
          0:{
              items:colxs,
              nav: navxs,
              dots:dotsxs,
              margin: marginxs
          },
          768:{
              items:colsm,
              nav: navsm,
              dots:dotssm,
              margin: marginsm
          },
          992:{
              items:colmd,
              nav: navmd,
              dots:dotsmd,
              margin: marginmd
          },
          1200:{
              items:collg,
              nav: navlg,
              dots:dotslg,
              margin: marginlg
          }
        },
        onInitialized: function () {
          $module.closest('.module-wrap[data-label="Carousel"]').addClass('gf-carousel-loaded');
          jQuery(window).trigger("resize");
        }
      });
    }
    
    // Fix nested carousel bug	
    if ($module.parent().parent().closest('.module-wrap[data-label="Carousel"]').length > 0) {	
        setTimeout(function() {	
            initCarousel();	
        }, 300)	
    } else {	
        initCarousel();	
    }
  } catch(err) {}
})( window.GemQuery || jQuery );
    
    
    
            
          
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917').children('.module');

  var sameHeightTitle = $module.data('sameheightitle'),
  spacing = $module.data('spacing');
  collg = $module.data('collg'),
  colmd = $module.data('colmd'),
  colsm = $module.data('colsm'),
  colxs = $module.data('colxs');

  var $clearfixes = $module.find('.gf_row-no-padding').children('.gf_clearfix');
  var col = collg;

  jQuery(window).resize(function() {
    setTimeout(function() {
      for(var i = 0; i < $clearfixes.length; i++) {
        if($clearfixes.eq(i).css('display') == 'block') {
          if($clearfixes.eq(i).hasClass('visible-lg')) {
            col = collg;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-md')) {
            col = colmd;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-sm')) {
            col = colsm;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-xs')) {
            col = colxs;
            break;
          }
        }
      }
    }, 1000);
  });

  jQuery($module).css('padding', spacing);
})( window.GemQuery || jQuery );
    
    
  
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child1').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child1-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child1-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child1-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child2').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child2-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child2-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child2-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child3').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child3-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child3-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child3-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child4').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child4-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child4-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child4-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child5').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child5-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child5-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child5-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child6').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child6-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child6-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child6-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child7').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child7-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child7-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child7-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child8').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640255475917-child8-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640255475917-child8-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640255475917-child8-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699').children('.module');

  var sameHeightTitle = $module.data('sameheightitle'),
  spacing = $module.data('spacing');
  collg = $module.data('collg'),
  colmd = $module.data('colmd'),
  colsm = $module.data('colsm'),
  colxs = $module.data('colxs');

  var $clearfixes = $module.find('.gf_row-no-padding').children('.gf_clearfix');
  var col = collg;

  jQuery(window).resize(function() {
    setTimeout(function() {
      for(var i = 0; i < $clearfixes.length; i++) {
        if($clearfixes.eq(i).css('display') == 'block') {
          if($clearfixes.eq(i).hasClass('visible-lg')) {
            col = collg;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-md')) {
            col = colmd;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-sm')) {
            col = colsm;
            break;
          }
          if($clearfixes.eq(i).hasClass('visible-xs')) {
            col = colxs;
            break;
          }
        }
      }
    }, 1000);
  });

  jQuery($module).css('padding', spacing);
})( window.GemQuery || jQuery );
    
    
  
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child1').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child1-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child1-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child1-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child2').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child2-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child2-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child2-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child3').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child3-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child3-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child3-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child4').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child4-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child4-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child4-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child5').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child5-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child5-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child5-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child6').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child6-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child6-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child6-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child7').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child7-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child7-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child7-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child8').children('.module');
  $module.gfV3Product();
})( window.GemQuery || jQuery );
    
(function(jQuery) {
  var $module = jQuery('#m-1640256097699-child8-0').children('.module');
  var effect = $module.attr('data-effect');
  var magnify = $module.attr('data-zoom-level');
  var displayType = $module.attr('data-displaytype');
  $module.gfV3ProductImage({
    'effect': effect,
    'displayType': displayType,
    'magnify': magnify
  });
})(window.GemQuery || jQuery);
    
    
(function(jQuery) {
    var $module = jQuery('#m-1640256097699-child8-2').children('.module');
    $module.gfV3ProductPrice({
        displayCurrency: true
    });
})(window.GemQuery || jQuery);
    
(function( jQuery ){
  var $module = jQuery('#m-1640256097699-child8-4').children('.module');
  var $product = $module.closest('[data-label="Product"]');
  var productCurrentId = "";
  if ($product.length > 0) {
    productCurrentId = $product.attr("id");
  }
  var changeVariantFunction = function (variant) {
    if(variant&&variant.id){
      var productHandle = $module.attr("data-phandle");
      var newHandle = "/products/"+productHandle+"?variant="+variant.id;
      $module.find('a').attr("href",newHandle);
    }
  }
  if (window.GEMSTORE) {
    window.GEMSTORE.subscribe("product-" + productCurrentId + "-variant", changeVariantFunction);
  }
})( window.GemQuery || jQuery );
    